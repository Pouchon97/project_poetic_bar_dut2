Login de l' administrateur:
Username= Admin
password= Admin


login du caissier:
Username= Caissier
password= Caissier


les realisateurs de ce projet:
Pouchon JEUDIUS
Sophie Laube MARCELUS
spencer VITAL


 règles de l'application:
 1- pour afficher les utilisateurs du système, on fait un clique sur l'onglet UTILISATEURS.
 a-l'administrateur peut supprimer ou editer le nom d'un utilisateur et ajouter un nouvel administrateur.


 2-pour gérer les ventes du système, le caissier doit faire clique sur l'onglet GESTION DES VENTES
 a-le caissier peut fournir les informations du produit vendu.
 b-le caissier peut voir la statistique des produits vendus en cliquant sur le l'onglet VIEW STATISTICS.
 c-le caissier peut aussi faire des mis a jur sur les produits vendus en cliquant sur l'onglet +GO TO CHECK FOR UPDATE.

 3-Gestion des produits:
  a-pour faire la géstion des produits  du système, l'administrateur fait un clique sur l'onglet GESTION DES PRODUITS.
  b-l'administrateur peut fournir les informations sur les produits.
  c- en cas d'erreur, l'administrateur a la possibilité d'anuler des enformations avec le bouton ANNULER.
   d- l'administrateur peut éditer, supprimer ou ajouter de nouveau produits.

   4-pour gérer les stocks, l'administrateur fait un clique sur le champs GESTION DES STOCKS.
   il peut voir le nom, le nombre et la quantité de produits en stock.