<?php
include("connection_DB.php");
include("classes/produit.class.php");
include("classes/produit_type.class.php");
include("classes/prix.class.php");
include("classes/stock.class.php");

        if(isset($_GET['produit_code'])){
            $produit_code= $_GET['produit_code'];
            $resultat = Produit::recuperation_produit_code_par_methode_get1($produit_code);
            $resultat = $resultat->fetchAll();
            
            foreach($resultat as $g){
                $produit_code = $g['produit_code'];
                $produit_name = $g['produit_name'];
                $type_produit = $g['type_produit'];
                $type_name = $g['type_name'];

            }

            $resultat1 =Produit::recuperation_produit_code_par_methode_get3($produit_code);
            foreach($resultat1 as $g){
                $quantite = $g['quantite'];
            }

            $resultat2 =Produit::recuperation_produit_code_par_methode_get2($produit_code);
            foreach($resultat2 as $g){
                $prix = $g['prix'];
            }
            

            
        }
?>

<?php
    if(isset($_POST['update_produit'])){
        $type_produit =htmlspecialchars(trim(strip_tags(addslashes(($_POST['type_produit'])))));
        $type_name =htmlspecialchars(trim(strip_tags(addslashes(($_POST['type_name'])))));
        $produit_code =htmlspecialchars(trim(strip_tags(addslashes(($_POST['produit_code'])))));
        $produit_name=htmlspecialchars(trim(strip_tags(addslashes(($_POST['produit_name'])))));
        $prix=htmlspecialchars(trim(strip_tags(addslashes(($_POST['prix'])))));
        $quantite=htmlspecialchars(trim(strip_tags(addslashes(($_POST['quantite'])))));

        $prix1= new Prix($prix,$produit_code);
        $quantite1 = new Stock($quantite,$produit_code);
        $produit_type1 = new Produit_type($type_produit,$type_name);
        $produit1= new Produit($produit_code,$produit_name,$type_produit);
        
        
        // recuperation des getters //
        
        $type_produit = $produit_type1->getType_produit();
        $type_name = $produit_type1->getType_name();
        $produit_code = $produit1->getProduit_code();
        $produit_name = $produit1->getProduit_name();
        $prix = $prix1->getPrix();
        $quantite = $quantite1->getQuantite();
        
        $res = Produit::modifier($type_name,$type_produit,$produit_code,$produit_name,$prix,$quantite);
    }

    if(isset($_POST['suprimer'])){
        $produit_code=$_GET['produit_code'];

        $res1 = Produit::suprimer($produit_code);

    }

?>

<form action="" method="POST">
    <center><h4 style="text-shadow:1px 2px 1px green;color:#383f39;margin-top:-20px;text-aligne:center;">Update produit</h4></center>
    <div class="form-group">
        <label for="exampleFormControlInput1">Ref produit</label>
        <input type="text" readonly="true" value="<?php if(isset($produit_code)){echo($produit_code);} ?>" name="produit_code" class="form-control" id="exampleFormControlInput1" placeholder="" required autocomplete="off">
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput1">Produit name</label>
        <input type="text" value="<?php if(isset($produit_name)){echo($produit_name);}  ?>" name="produit_name" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput1">Prix</label>
        <input type="number" value="<?php if(isset($prix)){echo($prix);} ?>" name="prix" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput1">Quantités</label>
        <input type="number" value="<?php if(isset($quantite)){echo($quantite);} ?>" name="quantite" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput1">Type produit</label>
        <input type="text" value="<?php if(isset($type_produit)){echo($type_produit);} ?>" readonly="true" name="type_produit" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput1">Type name </label>
        <input type="text" value="<?php if(isset($type_name)){echo($type_name);} ?>" name="type_name" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
   </div>

    <div class="form-group">
        <button style="color:white;border:none;width:100px;float:left;margin-right:20px;top:-10px;background:#4c4c4c;" type="submit" name="update_produit" class="btn btn-success"><i class="fa fa-paper-plane" aria-hidden="true"></i> Update</button>
       
        </div>
        <?php if(isset($res)){echo('<button style="color:white;border:none;width:300px;float:left;margin-right:20px;top:-10px;background:#764600;" type="submit"  class="btn btn-success"><i class="fa fa-user" aria-hidden="true"></i> Update Successfuly...</button>');} ?>
        <?php if(isset($res1)){echo('<button style="color:white;border:none;width:300px;float:left;margin-right:20px;top:-10px;background:#764600;" type="submit"  class="btn btn-success"><i class="fa fa-user" aria-hidden="true"></i> Delete Successfuly...</button>');} ?>
</form>
<a href='?produit'><button style="color:white;border:none;width:200px;float:right;margin-right:20px;top:-10px;background:green;" type="bottom" class="btn btn-success"><i class="fa fa-refresh" aria-hidden="true"></i>Check to update product</button></a>