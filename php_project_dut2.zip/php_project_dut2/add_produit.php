<?php

    include("connection_DB.php");
    include('classes/produit_type.class.php');
    include('classes/produit.class.php');
    include("classes/prix.class.php");
    include("classes/stock.class.php");

    /// triatement du formulaire //
    if(isset($_POST['enregistre_produit'])){
        $type_produit =htmlspecialchars(trim(strip_tags(addslashes(($_POST['type_produit'])))));
        $type_name =htmlspecialchars(trim(strip_tags(addslashes(($_POST['type_name'])))));
        $produit_code = htmlspecialchars(trim(strip_tags(addslashes(($_POST['produit_code'])))));
        $produit_name =htmlspecialchars(trim(strip_tags(addslashes(($_POST['produit_name'])))));
        $prix =htmlspecialchars(trim(strip_tags(addslashes(($_POST['prix'])))));
        $quantite=htmlspecialchars(trim(strip_tags(addslashes(($_POST['quantite'])))));

        $produit_type1 = new Produit_type($type_produit,$type_name);
        $produit1= new Produit($produit_code,$produit_name,$type_produit);
        $prix1 = new Prix($prix,$produit_code);
        $quantite1 = new Stock($quantite,$produit_code);
        
        // recuperation des getters //
        
        $type_produit = $produit_type1->getType_produit();
        $type_name = $produit_type1->getType_name();
        $produit_code = $produit1->getProduit_code();
        $produit_name = $produit1->getProduit_name();
        $prix = $prix1->getPrix();
        $quantite = $quantite1->getQuantite();
        
        $res = Produit::insertion_all($type_produit,$type_name,$produit_code,$produit_name,$prix,$quantite);
   
    }


    
?>

<form action="" method="POST">
    <center><h4 style="text-shadow:1px 2px 1px green;color:#383f39;margin-top:-20px;text-aligne:center;">Add Produits</h4></center>
    <div class="form-group">
        <label for="exampleFormControlInput1">Ref produit</label>
        <input type="text" value="" name="produit_code" class="form-control" id="exampleFormControlInput1" placeholder="" required autocomplete="off">
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput1">Produit name</label>
        <input type="text" name="produit_name" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput1">Prix</label>
        <input type="number" name="prix" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput1">Quantités</label>
        <input type="number" name="quantite" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput1">Type produit</label>
        <input type="text" name="type_produit" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    <div class="form-group">
       <label for="exampleFormControlInput1">Type name </label>
       <input type="text" name="type_name" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    <div class="form-group">
    <button style="color:white;border:none;width:100px;float:left;margin-right:20px;top:-10px;background:#4c4c4c;" type="submit" name="enregistre_produit" class="btn btn-success"><i class="fa fa-paper-plane" aria-hidden="true"></i> Envoyer</button>
        <button style="color:white;border:none;width:100px;float:left;margin-right:20px;top:-10px;background:green;" type="reset" class="btn btn-success"><i class="fa fa-refresh" aria-hidden="true"></i>Annuler</button>
        <?php if(isset($res)){if($res){echo('<button style="color:white;border:none;width:300px;float:left;margin-right:20px;top:-10px;background:#764600;" type="submit" name="update_produit" class="btn btn-success"><i class="fa fa-user" aria-hidden="true"></i> Add Successfuly...</button>');}} ?>
    </div>                        
</form>
<a href="?produit"> <button style="color:white;border:none;width:210px;float:right;top:-10px;background:#4c4c4c;" type="submit" name="enregistre_produit" class="btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> check to update product</button></a>