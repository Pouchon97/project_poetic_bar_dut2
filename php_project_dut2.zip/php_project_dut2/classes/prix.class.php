<?php
    class Prix 
    {
        private $code_prix;
        private $prix;
        private $produit_code;

        public function __construct($prix,$produit_code){$this->setPrix($prix);$this->setProduit_code($produit_code);}
        public function getPrix(){return $this->prix;}
        public function getProduit_code(){return $this->produit_code;}

        public function setPrix($prix){return $this->prix = $prix;}
        public function setProduit_code($produit_code){return $this->produit_code = $produit_code;}

    }

?>