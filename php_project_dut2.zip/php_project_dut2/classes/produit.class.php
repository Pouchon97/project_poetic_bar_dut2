<?php

    class Produit
    {
        private $produit_code;
        private $produit_name;
        private $type_produit;

        public function __construct($produit_code,$produit_name,$type_produit){
            $this->setProduit_code($produit_code);
            $this->setProduit_name($produit_name);
            $this->setType_produit($type_produit);
        }
                // les getters//
        public function getProduit_code(){return $this->produit_code;}
        public function getProduit_name(){return $this->produit_name;}
        public function getType_produit(){return $this->type_produit;}
                // les setters// 
        public function setProduit_code($produit_code){return $this->produit_code = $produit_code;}
        public function setProduit_name($produit_name){return $this->produit_name = $produit_name;}
        public function setType_produit($type_produit){return $this->type_produit = $type_produit;}
    
        public static function recuperation_produit_code_par_methode_get1($produit_code){
            include("connection_DB.php");
            $sql="SELECT produit.produit_code,produit.produit_name,produit_type.type_produit,produit_type.type_name FROM produit INNER JOIN produit_type WHERE produit.type_produit = produit_type.type_produit AND  produit.produit_code ='$produit_code'";
            $execution = $con->query($sql);
            return $execution;

        }

        public static function recherche($produit_code){
            include("connection_DB.php");
            $sql="SELECT produit.produit_code,produit.produit_name,produit_type.type_produit,produit_type.type_name FROM produit INNER JOIN produit_type WHERE produit.type_produit = produit_type.type_produit AND produit.produit_code = '$produit_code'";
            $execution = $con->query($sql);
            return $execution;

        }
        public static function recuperation_produit_code_par_methode_get2($produit_code){
           include("connection_DB.php");
            $sql="SELECT * FROM prix  WHERE produit_code ='$produit_code'";
            $execution = $con->query($sql);
            return $execution;

        }
        public static function recuperation_produit_code_par_methode_get3($produit_code){
            include("connection_DB.php");
            $sql="SELECT * FROM stock  WHERE produit_code ='$produit_code'";
            $execution = $con->query($sql);
            return $execution;

        }


        public static function insertion_all($type_produit,$type_name,$produit_code,$produit_name,$prix,$quantite){
            include("connection_DB.php");
            $con->BeginTransaction();
            try{
            $sql='INSERT INTO produit_type(type_produit,type_name) VALUES (:type_produit, :type_name)';
            $result = $con->prepare($sql);
            $result->BindParam(':type_produit',$type_produit);
            $result->BindParam(':type_name',$type_name);
            $v1 = $result->execute();
            
    
            $sql='INSERT INTO produit(produit_code,produit_name,type_produit) VALUES (:produit_code, :produit_name, :type_produit)';
            $result = $con->prepare($sql);
            $result->BindParam(':produit_code',$produit_code);
            $result->BindParam(':produit_name',$produit_name);
            $result->BindParam(':type_produit',$type_produit);
            $result->execute();
            
            $sql='INSERT INTO prix(prix,produit_code) VALUES (:prix, :produit_code)';
            $result = $con->prepare($sql);
            $result->BindParam(':prix',$prix);
            $result->BindParam(':produit_code',$produit_code);
            $result->execute();
           
            
            $sql='INSERT INTO stock(quantite,produit_code) VALUES (:quantite, :produit_code)';
            $result = $con->prepare($sql);
            $result->BindParam(':quantite',$quantite);
            $result->BindParam(':produit_code',$produit_code);
            $v4=$result->execute();

            $con = $con->commit();
            return $v1;
            }catch(Exception $e){
                $con->rollBack();
                //echo("echec".$e->getMessage());
            }
        }


        public static function selection_par_jouinture(){
            include("connection_DB.php");
            $sql="SELECT produit.produit_code,produit.produit_name,produit_type.type_produit,produit_type.type_name FROM produit INNER JOIN produit_type WHERE produit.type_produit=produit_type.type_produit";
            $execution = $con->query($sql);
            return $execution;
        }

        public static function selection_par_recherche($recherche){
            include("connection_DB.php");
            $sql="SELECT produit.produit_code,produit.produit_name,produit_type.type_produit,produit_type.type_name FROM produit INNER JOIN produit_type WHERE produit.type_produit=produit_type.type_produit";
            $execution = $con->query($sql);
            return $execution;
        }


        public function modifier($type_name,$type_produit,$produit_code,$produit_name,$prix,$quantite){
            include("connection_DB.php");
            $con->BeginTransaction();
            try{
            $sql="UPDATE produit_type SET type_name=:type_name WHERE type_produit=:type_produit";
            $result = $con->prepare($sql);
            $result->BindParam(':type_name',$type_name);
            $result->BindParam(':type_produit',$type_produit);
            $v1 = $result->execute();
    
            $sql2="UPDATE produit SET  produit_name=:produit_name WHERE produit_code=:produit_code";
            $result = $con->prepare($sql2);
            $result->BindParam(':produit_name',$produit_name);
            $result->BindParam(':produit_code',$produit_code);
            $v2 = $result->execute();
    
            $sql3="UPDATE stock SET quantite=:quantite WHERE produit_code=:produit_code";
            $result = $con->prepare($sql3);
            $result->BindParam(':quantite',$quantite);
            $result->BindParam(':produit_code',$produit_code);
            $v2 = $result->execute();
    
            $sql4="UPDATE prix SET  prix=:prix WHERE produit_code=:produit_code";
            $result = $con->prepare($sql4);
            $result->BindParam(':prix',$prix);
            $result->BindParam(':produit_code',$produit_code);
            $v2 = $result->execute();
    
            $con->commit();
            return $v1;
            }catch(Exception $e){
                $con->rollBack();
                //echo("echec".$e->getMessage());
            }
        }


        public static function suprimer($produit_code){
            include("connection_DB.php");
            $sql4="DELETE FROM produit WHERE produit_code=:produit_code";
            $result = $con->prepare($sql4);
            $result->BindParam(':produit_code',$produit_code);
            $v2 = $result->execute();
            return $v2;

        }


    }

        


       

    


?>