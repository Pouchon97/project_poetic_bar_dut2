<?php

    class Produit_type
    {
        private $type_produit;
        private $type_name;

        public function __construct($type_produit,$type_name)
        {
            $this->setType_produit($type_produit);
            $this->setType_name($type_name);
        }

        public function getType_produit(){return $this->type_produit;}
        public function setType_name($type_name){$this->type_name = $type_name;}

        public function setType_produit($type_produit){$this->type_produit = $type_produit;}
        public function getType_name(){return $this->type_name;}
        
    }

?>