<?php

   class Stock
   {
       private $code_stock;
       private $quantite;
       private $produit_code;

       public function __construct($quantite,$produit_code){$this->setQuantite($quantite);$this->setProduit_code($produit_code);}
       
       public function getQuantite(){return $this->quantite;}
       public function getProduit_code(){return $this->produit_code;}

       public function setQuantite($quantite){return $this->quantite = $quantite;}
       public function setProduit_code($produit_code){return $this->produit_code = $produit_code;}
    

       public static function selection_par_jouinture(){
        include("connection_DB.php");
        $sql="SELECT produit.produit_code,produit.produit_name,produit.type_produit,stock.quantite FROM produit INNER JOIN stock WHERE produit.produit_code=stock.produit_code";
        $execution = $con->query($sql);
        return $execution;
    }
    
    }


?>