<?php

    class Vente_produit
    {
        private $code_vente;
        private $qte;
        private $total;
        private $date_vente;
        private $code_produit;


        public function __construct($qte,$total,$date_vente,$code_produit)
        {
            $this->setQte($qte);
            $this->setTotal($total);
            $this->setDate_vente($date_vente);
            $this->setCode_produit($code_produit);
        }

        
        public function getQte(){return $this->qte;}
        public function getTotal(){return $this->total;}
        public function getDate_vente(){return $this->date_vente;}
        public function getCode_produit(){return $this->code_produit;}

        public function setQte($qte){return $this->qte = $qte;}
        public function setTotal($total){return $this->total = $total;}
        public function setDate_vente($date_vente){return $this->date_vente = $date_vente;}
        public function setCode_produit($code_produit){return $this->code_produit = $code_produit;}


    }
?>