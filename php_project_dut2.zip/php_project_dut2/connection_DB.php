<?php
    $con = new PDO('mysql:host=127.0.0.1;dbname=poetic_database;charset=utf8','root','');
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>