-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2020 at 09:23 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poetic_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `prix`
--

CREATE TABLE `prix` (
  `code_prix` int(11) NOT NULL,
  `prix` float NOT NULL,
  `produit_code` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prix`
--

INSERT INTO `prix` (`code_prix`, `prix`, `produit_code`) VALUES
(1, 600, '0001'),
(2, 80, '0002'),
(3, 20, '0003'),
(4, 30, '0004'),
(5, 700, '0005');

-- --------------------------------------------------------

--
-- Table structure for table `produit`
--

CREATE TABLE `produit` (
  `produit_code` varchar(50) NOT NULL,
  `produit_name` varchar(50) NOT NULL,
  `type_produit` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produit`
--

INSERT INTO `produit` (`produit_code`, `produit_name`, `type_produit`) VALUES
('0001', 'Asus', 'electronique'),
('0002', 'idole', 'cosmetiques'),
('0003', 'jugoo', 'alimentaire'),
('0004', 'creme a la glace', 'energetique'),
('0005', 'mon blanc', 'hygienique');

-- --------------------------------------------------------

--
-- Table structure for table `produit_type`
--

CREATE TABLE `produit_type` (
  `type_produit` varchar(50) NOT NULL,
  `type_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produit_type`
--

INSERT INTO `produit_type` (`type_produit`, `type_name`) VALUES
('alimentaire', 'jus'),
('cosmetiques', 'creme'),
('electronique', 'ordinateur portable'),
('energetique', 'pathens'),
('hygienique', 'parfum');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `code_stock` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  `produit_code` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`code_stock`, `quantite`, `produit_code`) VALUES
(1, 5, '0001'),
(2, 10, '0002'),
(3, 15, '0003'),
(4, 20, '0004'),
(5, 20, '0005');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `role`, `password`) VALUES
(1, 'Admin', 'ADMIN', 'Admin'),
(4, 'Caissier', 'Caissier', 'Caissier');

-- --------------------------------------------------------

--
-- Table structure for table `vente_produit`
--

CREATE TABLE `vente_produit` (
  `code_vente` int(11) NOT NULL,
  `qte` int(11) NOT NULL,
  `total` float NOT NULL,
  `date_vente` date NOT NULL,
  `produit_code` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vente_produit`
--

INSERT INTO `vente_produit` (`code_vente`, `qte`, `total`, `date_vente`, `produit_code`) VALUES
(1, 2, 1200, '2020-07-17', '0001'),
(2, 2, 160, '2020-07-18', '0002'),
(3, 4, 80, '2020-07-19', '0003'),
(4, 5, 150, '2020-07-22', '0004'),
(5, 2, 1400, '2020-07-21', '0005');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prix`
--
ALTER TABLE `prix`
  ADD PRIMARY KEY (`code_prix`),
  ADD KEY `PRIX_PRODUIT_FK` (`produit_code`);

--
-- Indexes for table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`produit_code`),
  ADD KEY `PRODUIT_PRODUIT_TYPE_FK` (`type_produit`);

--
-- Indexes for table `produit_type`
--
ALTER TABLE `produit_type`
  ADD PRIMARY KEY (`type_produit`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`code_stock`),
  ADD KEY `STOCK_PRODUIT_FK` (`produit_code`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vente_produit`
--
ALTER TABLE `vente_produit`
  ADD PRIMARY KEY (`code_vente`),
  ADD KEY `VENTE_PRODUIT_PRODUIT_FK` (`produit_code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prix`
--
ALTER TABLE `prix`
  MODIFY `code_prix` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `code_stock` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `vente_produit`
--
ALTER TABLE `vente_produit`
  MODIFY `code_vente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `prix`
--
ALTER TABLE `prix`
  ADD CONSTRAINT `PRIX_PRODUIT_FK` FOREIGN KEY (`produit_code`) REFERENCES `produit` (`produit_code`);

--
-- Constraints for table `produit`
--
ALTER TABLE `produit`
  ADD CONSTRAINT `PRODUIT_PRODUIT_TYPE_FK` FOREIGN KEY (`type_produit`) REFERENCES `produit_type` (`type_produit`);

--
-- Constraints for table `stock`
--
ALTER TABLE `stock`
  ADD CONSTRAINT `STOCK_PRODUIT_FK` FOREIGN KEY (`produit_code`) REFERENCES `produit` (`produit_code`);

--
-- Constraints for table `vente_produit`
--
ALTER TABLE `vente_produit`
  ADD CONSTRAINT `VENTE_PRODUIT_PRODUIT_FK` FOREIGN KEY (`produit_code`) REFERENCES `produit` (`produit_code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
