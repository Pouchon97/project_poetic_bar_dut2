<?php
  include("classes/stock.class.php");
  $execution = Stock::selection_par_jouinture();
  $data = $execution->fetchAll();

?>

<?php


?>
<div class="card" style="border:3px solid #5c5a57; float:right;width:1100px;box-shadow:1px 1px 5px green;">
  <div class="card-body">
  <table class="table">
  <thead class="thead-dark">
    <tr style="background:#5c5a57;color:blue">
      <th style="color:white;font-weight:bolder;" scope="col">code produit </th>
      <th style="color:white;font-weight:bolder;"scope="col"> produit name</th>
      <th style="color:white;font-weight:bolder;"scope="col">Type produit</th>
      <th style="color:white;font-weight:bolder;"scope="col">Quantite</th>
    </tr>
  </thead>
  <tbody>
  <?php
    foreach($data as $rs){
      echo("
          <tr>
              <td>$rs[produit_code]</td>
              <td>$rs[produit_name]</td>
              <td>$rs[type_produit]</td>
              <td>$rs[quantite]</td>
          </tr>
      ");
    } //<td><a href='main.php?produit_code=$rs[produit_code]'><button type='submit' name='Delete' style='background:red;color:white;border:none;width:100%;' class='btn btn-success'><i class='fa fa-trash' aria-hidden='true'></i> Suprimer</button></a><td>?>
  </tbody>
</table>

  </div>
</div>