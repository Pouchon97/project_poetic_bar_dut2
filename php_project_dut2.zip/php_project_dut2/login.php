<?php
session_start();

?>
<!DOCTYPE html >
<head >
    <meta charset = "utf-8" />
    <meta http - equiv = "X-UA-Compatible" content = "IE=edge,chrome=1" />
    <title >
       Authentification
    </title >
    <meta content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name = 'viewport' />
    <link rel = "stylesheet" type = "text/css" href = "https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel = "stylesheet" href = "https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" ><link href = "css/material-kit.css?v=2.0.5" rel = "stylesheet" />

</head >

<body class="login-page sidebar-collapse" >
<nav class="navbar navbar-transparent navbar-color-on-scroll fixed-top navbar-expand-lg" id = "sectionsNav" >
    <div class="container" >

</nav >
<div class="page-header header-filter" style ="" background-size: cover; background-position: top center;" >
    <div class="container" >
        <?php
        include("users.class.php");
        if(isset($_POST['login'])){
            $username = $_POST['username'];
            $password = $_POST['password'];
            $resultat = User::Selection_utilisateur($username,$password);
            $resultat =$resultat->fetchAll();
            
            if($resultat){
                $_SESSION['username'] = $username;
                $_SESSION['password'] = $password;
                $_SESSION['role'] = $role;
              header('Location:main.php?Acceuil');

            }else{
                //Falhou
                echo '<div class="erro-box"><i class="fa fa-times"></i> Username Or Password is incorest!</div>';
            }
        }
        ?>
        <div class="col-lg-4 col-md-6 ml-auto mr-auto" >
            <div class="card card-login" >

                <form class="form" method = "post" action="">
                    <div class="card-header card-header-primary text-center" >

                        <h4 class="card-title" > Se Connecter</h4 >
                    </div >
                    <div class="card-body" >
                        <div class="input-group" >
                            <div class="input-group-prepend" >
                    <span class="input-group-text" >
                      <i class="material-icons" > face</i >
                    </span >
                            </div >
                            <label >
                                <input autocomplete="off" type = "text" class="form-control" placeholder = "Digite o usuario..." name = "username" >
                            </label >
                        </div >
                        <div class="input-group" >
                            <div class="input-group-prepend" >
                    <span class="input-group-text" >
                      <i class="material-icons" > lock_outline</i >
                    </span >
                            </div >
                            <label >
                                <input type = "password" class="form-control" placeholder = "Digite a senha" name = "password" >
                            </label >
                        </div >
                        <button type = "submit"  name = "login" class="btn btn-primary">Connection</button >
                    </div >
                </form >
            </div >
        </div >
    </div >
    <footer class="footer" >
        <div class="container" >

            <div class="copyright " >
                &copy; GAMA SOFTWARE
            </div >
        </div >
    </footer >
</div >
<!--Core JS Files-->
<script src = "js/core/jquery.min.js" type = "text/javascript" ></script >
<script src = "js/core/popper.min.js" type = "text/javascript" ></script >
<script src = "js/core/bootstrap-material-design.min.js" type = "text/javascript" ></script >
<script src = "js/material-kit.js?v=2.0.5" type = "text/javascript" ></script >
</body >