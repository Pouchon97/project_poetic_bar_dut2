<?php
session_start();
if(!isset($_SESSION['username']) AND !isset($_SESSION['password'])){
    header("LOCATION:login.php");
}


?>
<!doctype html>
<html lang="pt-br">
<head>

    <meta charset="utf-8"/>
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <title> Gestion Poetic-bar</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>

    <!-- Bootstrap core CSS     -->
    <link href="css/bootstrap.min.css" rel="stylesheet"/>
    <!--<link href="bootstrap4/css/bootstrap.min.css" rel="stylesheet"/>!--

    <!-- Animation library for notifications   -->
    <link href="css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="css/demo.css" rel="stylesheet"/>

    <link href="css/style.css" rel="stylesheet">



    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="css/pe-icon-7-stroke.css" rel="stylesheet"/>

</head>
<body>

<div class="wrapper">

    <div class="sidebar" data-color="purple" data-image="img/aa.jpg">


        <div class="sidebar-wrapper" style="background:#3c3a38;">
            <div class="logo">
                <img src="img/adm.png" alt="logo" width="60px">
                <p>POETIC BAR</p>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="?Acceuil">
                        <i class="pe-7s-home"></i>
                        <p>Aceuil</p>
                    </a>
                </li>
                <!-- <li>
                    <a href="?pg=usuario">
                        <i class="pe-7s-user"></i>
                        <p>Usuarios</p>
                    </a>
                </li> -->
               

                <?php if(($_SESSION['username'])==='Caissier'){ 
                    echo('
                    <li>
                    <a href="?ventes">
                        <i class="pe-7s-cart"></i>
                        <p>Gestion de Ventes</p>
                    </a>
                </li>
                    ');
               
                }?>
                <?php if(($_SESSION['username'])=='Admin'){
                    echo('

                    <li>
                    <a href="?users">
                        <i class="pe-7s-users"></i>
                        <p> utilisateur</p>
                    </a>
                    </li>
                    
                
                    <li>
                    <a href="?produits">
                        <i class="pe-7s-bandaid"></i>
                        <p>Gestion Produits</p>
                    </a>
                </li>
                
                <li>
                    <a href="#">
                        <i class="pe-7s-chat"></i>
                        <p>chat</p>
                    </a>
                </li>
                <li>
                    <a href="?stocks">
                        <i class="pe-7s-graph2"></i>
                        <p>Gestion des Stocks</p>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="pe-7s-tools"></i>
                        <p>Parametes</p>
                    </a>
                </li>
            
            
                    ');
                }
                ?>
        </div>
    </div>


    <div class="main-panel">
    <?php if(!isset($_GET['Acceuil'])) {?>
        <nav class="navbar navbar-default navbar-fixed"  style="box-shadow:1px 1px 10px ;">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse"
                            data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#"></a>
                </div>
                <div class="collapse navbar-collapse">


                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="session_destroy.php">
                                <i class="fa fa-sign-out" aria-hidden="true" style="background:;margin-left:-160px;color:;">Déconnexion</i>
                            </a>
                        </li>
                    </ul>
                    <form action="" method="GET">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <div class="col-md-6 mb-3" style="margin-top:15px;margin-left:-800px;">

                                <input autocomplete="off" name="recherche_produit" style="width:380px;border:2px solid #515752;green;background:#b3b1b1;" type="text" class="form-control " id="validationServer01" placeholder=" entrez produit code" value="" required>
                               

                            </div>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <div class="col-md-6 mb-3" style="margin-top:15px;margin-left:-390px;">
                                <input style="margin-right:-100px;width:100px;border-color:green;background:#515752;color:white;" type="submit" class="form-control " id="validationServer01" placeholder="" value="Search"/> 
                               

                            </div>
                        </li>
                    </ul>
                    </form>
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <div class="col-md-6 mb-3" style="margin-top:25px;margin-left:10px;">
                            <bottom type="submit">
                            <i class="fa fa-user" aria-hidden="true" style="margin-left:10px;font-size:30px;color:#575757;"></i>
                            </bottom>
                            </div>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-left">
                        <li>
                        <div class="form-check" style="color:white;">
                            <label class="form-check-label">
                                <input style="margin-top:35px;margin-left:10px;" class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                <?php echo($_SESSION['username'].' '.' est connecté ...');?>
                            </label>
                        </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    <?php } ?>

        <div class="content">
            <div class="container-fluid">
                    <?php
                        if(isset($_GET['recherche_produit'])){
                            include("rechere_produit.php");
                        }
                    ?>

                    <?php 
                        if(isset($_GET['main.php'])){
                            echo("yes");
                        }

                    ?>
                    <?php 

                        if(isset($_GET['users'])){
                            include("user.php");
                        }

                        if(isset($_GET['id'])){
                            include("user.php");
                        }
                    ?>

                    <?php 
                        if(isset($_GET['ventes'])){
                           include("vente_produit.php");
                        }


                        if(isset($_GET['gestion_vente'])){
                            include("gestion_vente.php");
                        }

                        if(isset($_GET['Aujourdhuit'])){
                            include("gestion_vente.php");
                        }

                        if(isset($_GET['date1']) AND isset($_GET['date2'])){
                            include("gestion_vente.php");
                        }

                        if(isset($_GET['code_vente'])){
                            include("update_vente.php");
                        }

                        if(isset($_GET['update_vente_produit'])){
                            include("update_vente_produit.php");
                        }

                        
                    ?>

                    <?php 
                        if(isset($_GET['produits'])){
                            include("add_produit.php");
                        }

                        if(isset($_GET['produit'])){
                            include("produit.php");
                        }
                    ?>


                    <?php 
                        if(isset($_GET['chat'])){
                           
                        }
                    ?>

                    <?php 
                        if(isset($_GET['stocks'])){
                           include('gestion_stock.php');
                        }
                    ?>

                    

                    <!--  les formulaire gerer par l' administrateur
                        pour manupiler les produits!-->

                    <?php
                    if(isset($_GET['Addproduit'])){
                        include("add_produit.php");
                        
                    }

                    ?>

                    <?php
                        if(isset($_GET['produit_code'])){
                            include("Update_produit.php");
                        }

                    ?>

                    <?php
                        if(isset($_GET['Acceuil'])){
                            echo('
                            <div style="border:3px solid white;border-radius:5px 5px 5px 5px;height:50px;text-align:center;background:#b3b1b1;font-size:30px;color:white;">
                                <p style="font-size:30px;"> <marquee behavior="2" direction="right"> Welcome to Poetic bar Check to add products into your cart</marquee> </p>
                            </div>
                            </br>
                            ');
                            
                        }
                    ?>
                    <?php 
                        if(isset($_GET['Acceuil'])){
                            echo("
                            <div style='width:auto;height:240px;'>
                            <div class='col-sm-3'>
                            <div class='box box-solid'>
                                <div class='box-body prod-body'>
                                <a href='?produits'><img src='images/images/PRESTIGE.jpg' width='100%' height='230px' class='thumbnail'></a>
                                    
                                </div>
                                <div class='box-footer'>
                                    <b></b>
                                </div>
                            </div>
                        </div>

                        <div class='col-sm-3'>
                        <div class='box box-solid'>
                            <div class='box-body prod-body'>
                            <a href='?produits'><img src='images/images/b2.jpg' width='100%' height='230px' class='thumbnail'></a>
                            </div>
                            <div class='box-footer'>
                                <b></b>
                            </div>
                        </div>
                    </div>

                    <div class='col-sm-3'>
                    <div class='box box-solid'>
                        <div class='box-body prod-body'>
                        <a href='?produits'><img src='images/large-dell-inspiron-15-5000-15.jpg' width='100%' height='230px' class='thumbnail'></a>
                          
                        </div>
                        <div class='box-footer'>
                            <b></b>
                        </div>
                    </div>
                </div>
                <div class='col-sm-3'>
                    <div class='box box-solid'>
                        <div class='box-body prod-body'>
                        <a href='?produits'><img src='images/images/History-of-Ice-Cream-1.jpg' width='100%' height='230px' class='thumbnail'></a>
                            
                        </div>
                        <div class='box-footer'>
                            <b></b>
                        </div>
                    </div>
                </div>
                </div>


                <div style='width:auto;height:250px;'>
                            <div class='col-sm-3'>
                            <div class='box box-solid'>
                                <div class='box-body prod-body'>
                                <a href='?produits'> <img src='images/images/bt1.jpg' width='100%' height='230px' class='thumbnail'></a>
                                    
                                </div>
                                <div class='box-footer'>
                                    <b></b>
                                </div>
                            </div>
                        </div>

                        <div class='col-sm-3'>
                        <div class='box box-solid'>
                            <div class='box-body prod-body'>
                            <a href='?produits'> <img src='images/lenovo-ideapad-320s-14ikb-14-laptop-grey.jpg' width='100%' height='230px' class='thumbnail'></a>
                                
                            </div>
                            <div class='box-footer'>
                                <b></b>
                            </div>
                        </div>
                    </div>

                    <div class='col-sm-3'>
                    <div class='box box-solid'>
                        <div class='box-body prod-body'>
                        <a href='?produits'><img src='images/images/bt2.jpg' width='100%' height='230px' class='thumbnail'></a>
                           
                        </div>
                        <div class='box-footer'>
                            <b></b>
                        </div>
                    </div>
                </div>
                <div class='col-sm-3'>
                    <div class='box box-solid'>
                        <div class='box-body prod-body'>
                        <a href='?produits'><img src='images/large-apple-10-5-ipad-pro-64-gb-space-grey-2017.jpg' width='100%' height='230px' class='thumbnail'></a>
    
                        </div>
                        <div class='box-footer'>
                            <b></b>
                        </div>
                    </div>
                </div>
                </div>


                <div style='width:auto;height:250px;'>
                <div class='col-sm-3'>
                <div class='box box-solid'>
                    <div class='box-body prod-body'>
                    <a href='?produits'> <img src='images/pc-specialist-vortex-minerva-xt-r-gaming-pc.jpg' width='100%' height='230px' class='thumbnail'></a>
                        
                    </div>
                    <div class='box-footer'>
                        <b></b>
                    </div>
                </div>
            </div>

            <div class='col-sm-3'>
            <div class='box box-solid'>
                <div class='box-body prod-body'>
                <a href='?produits'> <img src='images/images/smartphone-vmobile-j6-telephone-portable-pas-cher.jpg' width='100%' height='230px' class='thumbnail'></a>
                    
                </div>
                <div class='box-footer'>
                    <b></b>
                </div>
            </div>
        </div>

        <div class='col-sm-3'>
        <div class='box box-solid'>
            <div class='box-body prod-body'>
            <a href='?produits'><img src='images/large-hp-barebones-omen-x-900-099nn-gaming-pc.jpg' width='100%' height='230px' class='thumbnail'></a>
               
            </div>
            <div class='box-footer'>
                <b></b>
            </div>
        </div>
    </div>
    <div class='col-sm-3'>
        <div class='box box-solid'>
            <div class='box-body prod-body'>
            <a href='?produits'><img src='images/images/782865613.png' width='100%' height='230px' class='thumbnail'></a>

            </div>
            <div class='box-footer'>
                <b></b>
            </div>
        </div>
    </div>
    </div>
                            
                
                
                ");

                        }
                    ?>


            </div>
        </div>


        <footer class="footer" style="margin-top:-30px;background:;">
            <div class="container-fluid">
                <p class="copyright pull-right" style="color:green;">
                    &copy;
                    <script>document.write(new Date().getFullYear())</script>
                    Pouchon Sfotware
                </p>
            </div>
        </footer>
    </div>
</div>
</body>

<script src="js/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="js/demo.js"></script>
<script src="assets/js/demo.js"></script>
<script type="text/javascript">

    $(document).ready(function () {
        // Javascript method's body can be found in assets/js/demos.js
        demo.initDashboardPageCharts();

        demo.showNotification();

    });
</script


</html>
