<?php
  include("classes/produit.class.php");
  $execution = Produit::selection_par_jouinture();
  $data = $execution->fetchAll();

?>

<?php


?>
<div class="card" style="border:3px solid #5c5a57;float:right;width:1100px;box-shadow:1px 1px 5px green;">
  <div class="card-body">
  <table class="table">
  <thead class="thead-dark">
    <tr style="background:#5c5a57;color:blue">
      <th style="color:white;font-weight:bolder;" scope="col">produit code </th>
      <th style="color:white;font-weight:bolder;" scope="col">Name</th>
      <th style="color:white;font-weight:bolder;" scope="col">Type produit</th>
      <th style="color:white;font-weight:bolder;" scope="col">Type name</th>
      
    </tr>
  </thead>
  <tbody>
  <?php
    foreach($data as $rs){
      echo("
          <tr>
              <td>$rs[produit_code]</td>
              <td>$rs[produit_name]</td>
              <td>$rs[type_produit]</td>
              <td>$rs[type_name]</td>
              <td><a href='main.php?produit_code=$rs[produit_code]'><button type='submit' name='Addproduit' style='background:blue;color:white;border:none;width:100%;' class='btn btn-success'><i class='fa fa-edit' aria-hidden='true'></i>Modifier</button></a><td>
              ||
              <td><a href='?Addproduit'><button type='submit' name='Delete' style='background:red;color:white;border:none;width:100%;' class='btn btn-success'><i class='fa fa-plus' aria-hidden='true'></i> Ajouter produit</button></a><td>
             
              
          </tr>
      ");
    } //<td><a href='main.php?produit_code=$rs[produit_code]'><button type='submit' name='Delete' style='background:red;color:white;border:none;width:100%;' class='btn btn-success'><i class='fa fa-trash' aria-hidden='true'></i> Suprimer</button></a><td>?>
  </tbody>
</table>

  </div>
</div>




<!-- <div class="card" style="float:left;width:400px;box-shadow:2px 2px 10px green;">
  <div class="card-body">
  <table class="table">
  <thead class="thead-dark">
  </thead>
  <tbody>
    <tr>
      <th scope="row">Quantitées produits</th>
      <td>200</td>
    </tr>
    <tr>
      <th scope="row">Prix unitaire</th>
      <td>2900 <i class="fa fa-usd" aria-hidden="true"></i></td>
    </tr>
    <tr>
      <th scope="row">Quantitées type prosuits</th>
      <td>5</td>
    </tr>
    <tr>
      <th scope="row">Quantitées type name</th>
      <td>44</td>
    </tr>
  </tbody>
</table>

  </div>
</div> -->


<!-- <form action="" method="POST">
<div class="card" style="float:left;width:400px;box-shadow:2px 2px 10px green;">
  <div class="card-body">
  <table class="table">
  <thead class="thead-dark">
  </thead>
  <tbody>
    <tr>
      <textarea style="height:110px;" class="form-control" placeholder="envoyez un texto a votre casier" id="exampleFormControlTextarea1" rows="3"></textarea>
    </tr>
    <tr>
      <th scope="row">Contactez votre caissier 
      <button style="color:white;border:none;width:100px;float:right;margin-right:20px;top:-10px;background:#4c4c4c;" type="submit" class="btn btn-success"><i class="fa fa-paper-plane" aria-hidden="true"></i> Envoyer</button>
      </th>
      </tr>
  </tbody>
</table>

  </div>
</div>
</form> -->


