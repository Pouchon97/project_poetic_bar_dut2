<?php
  include("connection_DB.php");
  $sql="SELECT vente_produit.code_vente, produit.produit_code,produit.produit_name,vente_produit.qte,vente_produit.total,vente_produit.date_vente FROM produit INNER JOIN vente_produit WHERE produit.produit_code=vente_produit.produit_code";
  $execution = $con->query($sql);
  $data = $execution->fetchAll();

 

?>
<div class="card" style="border:3px solid #5c5a57;float:right;width:1100px;box-shadow:1px 1px 5px green;">
  <div class="card-body">
  <table class="table">
  <thead class="thead-dark">
    <tr style="background:#5c5a57;">
      <th style="color:white;font-weight:bolder;"  scope="col">code vente </th>
      <th style="color:white;font-weight:bolder;" scope="col">produit code</th>
      <th style="color:white;font-weight:bolder;" scope="col"> produit name</th>
      <th style="color:white;font-weight:bolder;" scope="col"> Quantite</th>
      <th style="color:white;font-weight:bolder;" scope="col">Total</th>
      <th style="color:white;font-weight:bolder;" scope="col">Date</th>
      <th style="color:white;font-weight:bolder;" scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php
    foreach($data as $rs){
      echo("
          <tr>
              <td>$rs[code_vente]</td>
              <td>$rs[produit_code]</td>
              <td>$rs[produit_name]</td>
              <td>$rs[qte]</td>
              <td>$rs[total]</td>
              <td>$rs[date_vente]</td>
              <td><a href='main.php?code_vente=$rs[code_vente]'><button type='submit' name='Addproduit' style='background:blue;color:white;border:none;width:100%;' class='btn btn-success'><i class='fa fa-edit' aria-hidden='true'></i>Modifier</button></a><td>
              || 
              <td><a href='main.php?Delete_prod=$rs[produit_code]'><button type='submit' name='Delete' style='background:red;color:white;border:none;width:100%;' class='btn btn-success'><i class='fa fa-plus' aria-hidden='true'></i> Ajouter vente</button></a><td>
             
              
          </tr>
      ");
    } ?>
  </tbody>
</table>

  </div>
</div>

