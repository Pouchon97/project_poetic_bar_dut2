<?php 

    class User{
        private $username;
        private $password;
        private $role;

        public function __construct($username,$role,$password)
        {
            $this->setUsername($username);
            $this->setRole($role);
            $this->setPassword($password);
        }


        public function setUsername($username){return $this->username = $username;}
        public function setRole($role){return $this->role = $role;}
        public function setPassword($password){return $this->password = $password;}
        public function getUsername(){return $this->username;}
        public function getRole(){return $this->role;}
        public function getPassword(){return $this->password;}


        public static function Selection_utilisateur($username,$password){
            include("connection_DB.php");
            $sql ="SELECT * FROM user WHERE username='$username' AND password='$password'";
            $resultat = $con->query($sql);
            return $resultat;
        }


        public static function select_by_id($id){
            include("connection_DB.php");
            $sql="SELECT * FROM user WHERE id='$id'";
            $execution = $con->query($sql);
            return $execution ;
        }

        public static function selection_all_user(){
            include("connection_DB.php");
            $sql="SELECT * FROM user";
            $execution = $con->query($sql);
            return $execution;
        }

        public static function insertion($username,$role,$password){
            include("connection_DB.php");
            $sql='INSERT INTO user(username,role,password) VALUES (:username, :role, :password)';
            $result = $con->prepare($sql);
            $result->BindParam(':username',$username);
            $result->BindParam(':role',$role);
            $result->BindParam(':password',$password);
            $resultat = $result->execute();
            return $resultat;
        }

        public static function modifier($username,$role,$password,$id){
            include("connection_DB.php");
            $sql="UPDATE user SET username=:username ,role=:role, password=:password  WHERE id=:id";
            $result = $con->prepare($sql);
            $result->BindParam(':username',$username);
            $result->BindParam(':role',$role);
            $result->BindParam(':password',$password);
            $result->BindParam(':id',$id);
            $resultat = $result->execute();
            return $resultat;
        }

        public static  function delete_user($id){
            include("connection_DB.php");
            $sql='DELETE  FROM user WHERE id=:id';
            $result = $con->prepare($sql);
            $result->BindParam(':id',$id);
            $resultat = $result->execute();
            return $resultat;
        }
    }

?>