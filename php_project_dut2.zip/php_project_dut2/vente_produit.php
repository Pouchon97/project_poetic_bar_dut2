<?php



  include("connection_DB.php");
  include("classes/vente_produit.class.php");

   $resultat = $con->query("SELECT produit_code FROM produit");
   
  
   if(isset($_POST['save_vente'])){
    $quantite =htmlspecialchars(trim(strip_tags(addslashes(($_POST['qte'])))));
    $total =htmlspecialchars(trim(strip_tags(addslashes(($_POST['total'])))));
    $produit_code = htmlspecialchars(trim(strip_tags(addslashes(($_POST['produit_code'])))));
    $date =htmlspecialchars(trim(strip_tags(addslashes(($_POST['date_vente'])))));

    $vente1= new Vente_produit($quantite,$total,$date,$produit_code);

    $quantite=$vente1->getQte();
    $total=$vente1->getTotal();
    $date=$vente1->getDate_vente();
    $produit_code=$vente1->getCode_produit();

        $sql='INSERT INTO vente_produit(qte,total,date_vente,produit_code) VALUES (:qte, :total, :dat, :produit_code)';
        $result = $con->prepare($sql);
        $result->BindParam(':qte',$quantite);
        $result->BindParam(':total',$total);
        $result->BindParam(':dat',$date);
        $result->BindParam(':produit_code',$produit_code);
        $v1 = $result->execute();

   }
 

?>

<form action="" method="POST">
     <center><h4 style="text-shadow:1px 2px 1px green;color:#383f39;margin-top:-20px;text-aligne:center;">Vente Produit</h4></center>
    <div class="form-group">
        <label for="exampleFormControlInput1">Produit code</label>
         <select name="produit_code"  class="custom-select d-block my-3" style="height:40px;text-align:center;width:140px;color:green;" class="form-control is-valid" name="produit_code" value="" required="true">
         <option value=""> </option>
            <?php while($row=$resultat->fetch()) {?>
            
            <option value="<?php echo($row[0]); ?>"><?php echo($row[0]); ?></option>
            <?php } ?>
         </select>
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput1"> Quantite</label>
        <input type="number"  value="" name="qte" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    <div class="form-group">
         <label for="exampleFormControlInput1">Total</label>
        <input type="number" value="" name="total" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
                                    
    </div>
    <div class="form-group">
         <label for="exampleFormControlInput1">Date Vente</label>
         <input type="date" value="" name="date_vente" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
   
    <div class="form-group">
        <button style="color:white;border:none;width:150px;float:left;margin-right:20px;top:-10px;background:green;" type="submit" name="save_vente"  class="btn btn-success"><i class="fa fa-paper-plane" aria-hidden="true"></i> Save</button>
        <?php if(isset($v1)){echo('<button style="color:white;border:none;width:200px;float:left;margin-right:20px;top:-10px;background:#d1931b;" type="submit" name="update_produit" class="btn btn-warning"><i class="fa fa-user" aria-hidden="true"></i> Add Succesfuly</button>');}?>
    </div>                               
</form>
<a href="?update_vente_produit"><button style="color:white;border:none;width:300px;float:right;margin-right:20px;top:-10px;background:#4c4c4c;" type="reset" class="btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Go to check for Update</button></a>
<a href="?gestion_vente"><button style="color:white;border:none;width:150px;float:right;margin-right:20px;top:-10px;background:green;" type="bottom"  class="btn btn-success"><i class="fa fa-eye" aria-hidden="true"></i> View satistics</button></a>